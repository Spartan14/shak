import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { RechargeComponent } from './recharge/recharge.component';
import { NewuserComponent } from './newuser/newuser.component';
import { HomepageComponent } from './homepage/homepage.component';
import { SearchComponent } from './search/search.component';
import { ShowComponent } from './show/show.component';
import { TransferComponent } from './transfer/transfer.component';
import { FilterPipe } from './filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    RechargeComponent,
    NewuserComponent,
    HomepageComponent,
    SearchComponent,
    ShowComponent,
    TransferComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
