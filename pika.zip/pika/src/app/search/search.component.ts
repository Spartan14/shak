import { Component, OnInit } from '@angular/core';
import data from '../../data/details.json'
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor() { }
  array=data
  flag=false
  ngOnInit() {
  }
  setFlag()
  {
    this.flag=true
  }
}
