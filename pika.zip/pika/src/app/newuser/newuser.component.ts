import { Component, OnInit } from '@angular/core';
import data from '../../data/details.json'

@Component({
  selector: 'app-newuser',
  templateUrl: './newuser.component.html',
  styleUrls: ['./newuser.component.css']
})
export class NewuserComponent implements OnInit {

  array=data
  accNum: number;
  successflag=false
    constructor() { }
  
    ngOnInit() {
    }
  
    add(form)
    {
      this.accNum=Math.floor(Math.random() * 10000) + 1 
      this.array.push({
        accNum: this.accNum, 
        name: form.name, 
        phone: form.phone, 
        email: form.email, 
        balance: 0})
      this.successflag=true;
    }

}
