import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomepageComponent} from './homepage/homepage.component'
import{NewuserComponent} from './newuser/newuser.component'
import{RechargeComponent} from './recharge/recharge.component'
import{SearchComponent} from './search/search.component'
import{ShowComponent} from './show/show.component'
import{TransferComponent} from './transfer/transfer.component'
const routes: Routes = [
  {
    path: '',
    component: HomepageComponent
  },
  {
    path: 'create',
    component: NewuserComponent
  },
  {
    path: 'search',
    component: SearchComponent
  },
  {
    path: 'addmoney',
    component: RechargeComponent
  },
  {
    path: 'transfer',
    component: TransferComponent
  },
  {
    path: 'showall',
    component: ShowComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
