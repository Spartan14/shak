export interface Message {
    message: string,
    fromId: string,
    toId: string,
}