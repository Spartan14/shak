package com.capstore.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstore.model.Merchant;
@Repository
public interface MerchantRepository extends JpaRepository<Merchant,Long> {
 
@Query("from Merchant m where m.email = :email")
Optional<Merchant> findByEmail(@Param("email")String email);

@Query("from Merchant m where m.id = :id")
List<Merchant> findByMerchantId(@Param("id")long id);

}
