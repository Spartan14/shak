package com.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstore.model.Customer_Orders;
@Repository
public interface CustomerOrderRepository extends JpaRepository<Customer_Orders, Integer> {

}
