package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.model.AdminLogin;
import com.capstore.model.Merchant;
import com.capstore.model.Customers;

import com.capstore.model.Customer_Orders;
import com.capstore.repository.CustomerOrderRepository;
import com.capstore.repository.CustomerRepository;
import com.capstore.repository.CapstoreRepository;
import com.capstore.repository.MerchantRepository;

@Service
public class CapStoreImpl implements ICapStore {
	@Autowired
	CapstoreRepository repository;
	@Autowired
	MerchantRepository merchantRepository;
	@Autowired
	CustomerOrderRepository orderRepository;
	@Autowired
	CustomerRepository customerRepository;

	public String login(String email, String password) {

		Optional<AdminLogin> opt = repository.findById(email);
		if (opt.isPresent()) {
			AdminLogin login = opt.get();
			if (login.getPassword().equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		} else {
			return "Login Failed";
		}

	}
	
	public String loginMerchant(String email, String password) {
		System.out.println(email);
		Optional<Merchant> opt = merchantRepository.findByEmail(email);
		if (opt.isPresent()) {
			Merchant login = opt.get();
			if (login.getPassword().equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		} else {
			return "Login Failed";
		}

	}

	public List<Merchant> getMerchant() {

		List<Merchant> list = new ArrayList<Merchant>();
		list = merchantRepository.findAll();
		return list;
	}

	@Override
	public String deleteMerchant(long merchantId) {
		Optional<Merchant> opt = merchantRepository.findById(merchantId);
		if (opt.isPresent()) {
			Merchant merchants = opt.get();
			merchantRepository.delete(merchants);
			return "Merchant details deleted successfully";

		} else {
			return "Merchant Not Found";
		}

	}

	@Override
	public List<Customer_Orders> showOrders() {

		List<Customer_Orders> list = new ArrayList<Customer_Orders>();
		list = orderRepository.findAll();
		return list;
	}

	@Override
	public String deleteOrder(int order_id) {
		Optional<Customer_Orders> opt = orderRepository.findById(order_id);
		if (opt.isPresent()) {
			Customer_Orders order = opt.get();
			orderRepository.delete(order);
			return "Order deleted successfully";

		} else {
			return "Order Not Found";
		}

	}

	public List<Customers> getCustomers() {
		List<Customers> list = new ArrayList<Customers>();
		list = customerRepository.findAll();
		return list;
	}

	public String deleteCustomers(long customerId) {
		Optional<Customers> opt = customerRepository.findById(customerId);
		if (opt.isPresent()) {
			Customers customer = opt.get();
			customerRepository.delete(customer);
		} else {
			return "Customer with " + customerId + " does not exist";
		}
		return "Customer details deleted successfully";
	}

	public String addMerchant(Merchant m) {
		merchantRepository.save(m);
		return "redirecting to your final step of signing up";
	}
	
	public List getProduct(long id)
	{
		return null;
		
	}
}
