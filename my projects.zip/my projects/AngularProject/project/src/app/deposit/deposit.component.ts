import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
//export class DepositComponent implements OnInit {
//  array=[]
 // user: any
//  flag=false
 // successflag=false
  //  constructor(private service: ClientService) { }
  
  //  ngOnInit() {
  //  }
  
   // find(number){
   //   this.service.findbyid(number).subscribe(data=> {this.array=data})
   //   this.flag=true    
   // }
   // update(number, amount){
   //   this.service.update(number,amount).subscribe(data=>{this.array=data})
    //  this.successflag=true
    //}
    export class DepositComponent implements OnInit {
      array=[]
      user: any
      flag=false
      successflag=false
      constructor(private service: ClientService) { }
  
      ngOnInit() {
      }
  
      find(number){
      this.service.findbyid(number).subscribe(data=> {this.array=data})
      this.flag=true    
    }
    update(number, amount){
      this.service.update(number,amount).subscribe(data=>{this.array=data})
      this.successflag=true
    }
}
