package com.cg.service;

import java.util.Scanner;

import com.cg.bean.PayBean;
import com.cg.dao.PayDao;

public class PayService {
	 PayDao paydao=new PayDao();
	 Scanner sc=new Scanner(System.in);
	
	
public void create(PayBean p)
{
	paydao.addUser(p);
}
public boolean deposit(long accno,double balance)
{
	return paydao.deposit(accno, balance);
		
}
public double display(long accno)
{
	double balance = paydao.display(accno);
	return balance;
	
}

public boolean Withdraw(long accno,double balance)
{
	boolean res = paydao.Withdraw(accno, balance);
	return res;
}

public boolean transferFund(long sourceaccno,long destinationaccno,double transferamount)
{
	boolean r=false;
	r = paydao.transferFund(sourceaccno, destinationaccno, transferamount);
	return r;
}
}

	

	
	
	 
	



