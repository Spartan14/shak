package com.account.WalletAccount.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import javax.persistence.Entity;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.WalletAccount.entity.Account;
import com.account.WalletAccount.exceptions.NoSuchAccountException;
import com.account.WalletAccount.exceptions.AccountsNotFoundException;

import com.account.WalletAccount.repository.AccountRepository;

@Service
@Transactional
public class AccountService {
	@Autowired
	AccountRepository accountRepository;
	
	
	public String insertAccount(Account entity) {
		accountRepository.saveAndFlush(entity);
		return "Account with Account id "+entity.getAccNo() + " added successfully";
    }
	public String removeAccount(int accNo) throws NoSuchAccountException{
		Optional<Account> opt=accountRepository.findById(accNo);
		if(opt.isPresent())
		 {
			Account emp=opt.get();
			accountRepository.delete(emp);
		 } 
		else {
			throw new NoSuchAccountException("Account with " + accNo + " does not exist");
		}
		return "AccNodetails deleted successfully";
	}
	
	public Account findAccount(int accNo) throws NoSuchAccountException{
		Optional<Account> opt=accountRepository.findById(accNo);
		if(opt.isPresent()) {
			Account entity=opt.get();
			Account odr = new Account();
			odr.setBalance(entity.getBalance());
			
			odr.setFname(entity.getFname());
			//odr.setMobNo(entity.getMobNo());
			
			
			return odr;
		}
		else {
			throw new NoSuchAccountException("Account with " + accNo + " does not exist");
		}
	}
	
	
	public List<Account> getAccount() throws AccountsNotFoundException{
		List<Account> entityList= accountRepository.findAll();
		if(entityList.isEmpty() || entityList.size()==0) {
			throw new AccountsNotFoundException("Orders details does not exist");
		}
		/*
		 * List<Accounts>list = new ArrayList(); for (Account entity : entityList) {
		 * Accounts ord = new Accounts(); ord.setAccNo(entity.getAccNo());
		 * ord.setBalance(entity.getBalance());
		 * 
		 * ord.setName(entity.getFname()); //ord.setMobNo(entity.getMobNo());
		 * 
		 * list.add(ord); }
		 */
		return entityList;
		
	}
	public Float updateAccount(Integer accno,Account user) throws NoSuchAccountException{
		Optional<Account> opt=accountRepository.findById(accno);
	
		if(opt.isPresent())
		 {
			
			Account entity=opt.get();
			entity.setBalance(entity.getBalance()+user.getBalance());
			return entity.getBalance();
			
		 } 
		else {
			throw new NoSuchAccountException("Account with " + accno + " does not exist");
		}
	}
	public float WithdrawAccount(int accNo,Account user) throws NoSuchAccountException{
		Optional<Account> opt=accountRepository.findById(accNo);
		
		if(opt.isPresent())
		 {
			
			Account entity=opt.get();
			entity.setBalance(entity.getBalance()-user.getBalance());
			return entity.getBalance();
			
		 } 
		else {
			throw new NoSuchAccountException("Accounts with " + accNo + " does not exist");
		}
	}
	public String transferAmount(int SourceAccNo,int destAccNo,Account user) throws NoSuchAccountException{
		Optional<Account> srcNo=accountRepository.findById(SourceAccNo);
		Optional<Account> desNo=accountRepository.findById(destAccNo);
		String stmt=null;
		if(srcNo.isPresent()&&desNo.isPresent())
		 {
			Account source=srcNo.get();
			Account destination=desNo.get();
			source.setBalance(source.getBalance()-user.getBalance());
			destination.setBalance(destination.getBalance()+user.getBalance());
			stmt="amount transfer from "+source.getAccNo()+" to "+destination.getAccNo()+" is "+user.getBalance();
		 } 
		return stmt;
		
	}



	

}
