package bean;

public class PayBean {
	long accno;
	long Sourceaccno,Destinationaccno;
	long phnno;
	String name;
	String address;
	double balance;
	public long getSourceaccno() {
		return Sourceaccno;
	}
	public void setSourceaccno(long sourceaccno) {
		Sourceaccno = sourceaccno;
	}
	public long getDestinationaccno() {
		return Destinationaccno;
	}
	public void setDestinationaccno(long destinationaccno) {
		Destinationaccno = destinationaccno;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	public long getAccno() {
		return accno;
	}
	public void setAccno(long accno) {
		this.accno = accno;
	}
	public long getPhnno() {
		return phnno;
	}
	public void setPhnno(long phnno) {
		this.phnno = phnno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public PayBean() {}
	public PayBean(long accno,String name,String address,long phnno,double balance)
	{
		this.accno=accno;
		this.name=name;
		this.phnno=phnno;
		this.address=address;
		this.balance=balance;	
	}

}
