package Demo;

import org.openqa.selenium.By;

public class ElementLocators {
	
	
	public static By FirstName=By.id("txtFirstName");
	public static By LastName=By.xpath("//input[@name='txtLN']");
	public static By Email=By.xpath("//input[@name='Email']");
	public static By Phone=By.xpath("//input[@name='Phone']");
	public static By Number_of_people_attend=By.xpath("//select[@name='size']");
	public static By Address=By.xpath("//textarea[@rows='5']");
	public static By City=By.xpath("//select[@name='city']");
	public static By State=By.xpath("//select[@name='state']");
	public static By Building_Name=By.id("txtAddress1");
	public static By Room_No=By.id("txtAddress1");
	public static By Conference_full_access_non_member=By.xpath("//select[@name=''/html/body/form/table/tbody/tr[13]/td[2]/input']");
	public static By Conference_full_access=By.xpath("//select[@name=''/html/body/form/table/tbody/tr[12]/td[2]/input'/html/body/form/table/tbody/tr[13]/td[2]/input]");
	public static By Area_Name=By.id("txtAddress2");
	public static By Card_Holder_Name=By.id("txtCardholderName");
	public static By Debit_Card_Number=By.id("txtDebit");
	public static By CVV=By.id("txtCvv");
	public static By Expiration_Month=By.id("txtMonth");
	public static By Expiration_Year=By.id("txtYear");
	public static By Next=By.xpath("//a[@href='#']");
	public static By Make_payment=By.xpath("//input[@value='MakePayment']");
	
	
	
	


}
