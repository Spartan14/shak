package stepdefinition;

import Demo.ElementLocators;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	@Given("^The user is on Registration  page$")
	public void the_user_is_on_Registration_page() throws Throwable {
		 PageFactPack.PageFactory.openbrowser("file:///C:/Users/apatha14/Desktop/M4%20set1%20webpages/ConferenceRegistartion.html#");
	    
	}

	@When("^user success on login page$")
	public void user_success_on_login_page() throws Throwable {
		// PageFactPack.PageFactory.openbrowser("file:///C:/Users/apatha14/Desktop/M4%20set1%20webpages/ConferenceRegistartion.html#");
	    
	}

	@When("^Enter the invalid first Name$")
	public void enter_the_invalid_first_Name() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.FirstName, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}
	


	@Then("^Accept the Alert for First Name$")
	public void accept_the_Alert_for_First_Name() throws Throwable {
	
		PageFactPack.PageFactory.Alert("Please   First Name");  
	}

	@Then("^Enter the valid First Name$")
	public void enter_the_valid_First_Name() throws Throwable {

		PageFactPack.PageFactory.SendValue(ElementLocators.FirstName, "Anuj");
	}

	@When("^Enter the invalid Last Name$")
	public void enter_the_invalid_Last_Name() throws Throwable {
	   
		PageFactPack.PageFactory.SendValue(ElementLocators.LastName, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Last Name$")
	public void accept_the_Alert_for_Last_Name() throws Throwable {
	 
		PageFactPack.PageFactory.Alert("Please  Last Name"); 
	}

	@Then("^Enter the valid Last Name$")
	public void enter_the_valid_Last_Name() throws Throwable {
	  
		PageFactPack.PageFactory.SendValue(ElementLocators.LastName, "Pathak");
	}

	@When("^Enter the invalid Email$")
	public void enter_the_invalid_Email() throws Throwable {
	   
		PageFactPack.PageFactory.SendValue(ElementLocators.Email, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Email$")
	public void accept_the_Alert_for_Email() throws Throwable {
	  
		PageFactPack.PageFactory.Alert("Please fill the Email");
	}

	@Then("^Enter the valid Email$")
	public void enter_the_valid_Email() throws Throwable {
	   
		PageFactPack.PageFactory.SendValue(ElementLocators.Email, "anujpathak@gmail.com");
	}

	@When("^Enter the invalid Mobile_no$")
	public void enter_the_invalid_Mobile_no() throws Throwable {
	
		PageFactPack.PageFactory.SendValue(ElementLocators.Phone, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Mobile_no$")
	public void accept_the_Alert_for_Mobile_no() throws Throwable {

		PageFactPack.PageFactory.Alert("Pleasecontact number");
	}

	@Then("^Enter the valid Mobile_no$")
	public void enter_the_valid_Mobile_no() throws Throwable {

		PageFactPack.PageFactory.SendValue(ElementLocators.Phone, "9193207896");
	}

	@When("^Enter the invalid Room_no$")
	public void enter_the_invalid_Room_no() throws Throwable {

		PageFactPack.PageFactory.SendValue(ElementLocators.Room_No, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Room_no$")
	public void accept_the_Alert_for_Room_no() throws Throwable {
	   
		PageFactPack.PageFactory.Alert("Please  Room number");
		}

	@Then("^Enter the valid Room_no$")
	public void enter_the_valid_Room_no() throws Throwable {
	
		PageFactPack.PageFactory.SendValue(ElementLocators.Room_No, "4A");
	}

	@When("^Enter the invalid City$")
	public void enter_the_invalid_City() throws Throwable {
	   
		PageFactPack.PageFactory.SendValue(ElementLocators.City, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for City$")
	public void accept_the_Alert_for_City() throws Throwable {
	  
		PageFactPack.PageFactory.Alert("Please valid City");
	}

	@Then("^Enter the valid City$")
	public void enter_the_valid_City() throws Throwable {

		PageFactPack.PageFactory.SendValue(ElementLocators.City, "Mathura");
	}

	@When("^Enter the invalid State$")
	public void enter_the_invalid_State() throws Throwable {
	  
		PageFactPack.PageFactory.SendValue(ElementLocators.State, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for State$")
	public void accept_the_Alert_for_State() throws Throwable {
	   
		PageFactPack.PageFactory.Alert("Please enter valid State");
	}

	@Then("^Enter the valid State$")
	public void enter_the_valid_State() throws Throwable {
	  
		PageFactPack.PageFactory.SendValue(ElementLocators.State, "UP");
	}

	@When("^Enter the invalid Number of people attending$")
	public void enter_the_invalid_Number_of_people_attending() throws Throwable {
	 
		PageFactPack.PageFactory.SendValue(ElementLocators.Number_of_people_attend, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Number of people attending$")
	public void accept_the_Alert_for_Number_of_people_attending() throws Throwable {
	
		PageFactPack.PageFactory.Alert("Please  Number of people");

	}

	@Then("^Enter the valid Number of people attending$")
	public void enter_the_valid_Number_of_people_attending() throws Throwable {
	
		PageFactPack.PageFactory.select(ElementLocators.Number_of_people_attend, "2");
	}

	@When("^Enter the invalid Member$")
	public void enter_the_invalid_Member() throws Throwable {

		PageFactPack.PageFactory.SendValue(ElementLocators.Conference_full_access, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Member$")
	public void accept_the_Alert_for_Member() throws Throwable {
	   
		PageFactPack.PageFactory.Alert("Please  Membership status");
	}

	@Then("^Enter the valid Member$")
	public void enter_the_valid_Member() throws Throwable {
	  
		PageFactPack.PageFactory.clickmethod(ElementLocators.Conference_full_access_non_member);
	}

	@When("^Enter the invalid Non Member$")
	public void enter_the_invalid_Non_Member() throws Throwable {
	    
		PageFactPack.PageFactory.SendValue(ElementLocators.Conference_full_access_non_member, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Non Member$")
	public void accept_the_Alert_for_Non_Member() throws Throwable {
	   
		PageFactPack.PageFactory.Alert("Please Select Membership status");
	}

	@Then("^Enter the valid Non Member$")
	public void enter_the_valid_Non_Member() throws Throwable {
	   
		PageFactPack.PageFactory.clickmethod(ElementLocators.Conference_full_access_non_member);
	}

	@Then("^User is scuccessfully logged in$")
	public void user_is_scuccessfully_logged_in() throws Throwable {
	 
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@When("^Enter the invalid Card holder name$")
	public void enter_the_invalid_Card_holder_name() throws Throwable {
	  
		PageFactPack.PageFactory.SendValue(ElementLocators.Card_Holder_Name, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Make_payment);
	}

	@Then("^Accept the Alert for Card holder name$")
	public void accept_the_Alert_for_Card_holder_name() throws Throwable {
	   
		PageFactPack.PageFactory.Alert("Please enter valid Card Holder name");
	}

	@Then("^Enter the valid Card holder name$")
	public void enter_the_valid_Card_holder_name() throws Throwable {

		PageFactPack.PageFactory.select(ElementLocators.Card_Holder_Name,"AnujPathak");
	}

	@When("^Enter the invalid Debit card number$")
	public void enter_the_invalid_Debit_card_number() throws Throwable {
	   
		PageFactPack.PageFactory.SendValue(ElementLocators.Debit_Card_Number, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Make_payment);
	}

	@Then("^Accept the Alert for Debit card number$")
	public void accept_the_Alert_for_Debit_card_number() throws Throwable {
	    
		PageFactPack.PageFactory.Alert("Please enter valid Debit card number");
	}

	@Then("^Enter the valid Debit card number$")
	public void enter_the_valid_Debit_card_number() throws Throwable {
	
		PageFactPack.PageFactory.select(ElementLocators.Debit_Card_Number,"9739767386210");
	}

	@When("^Enter the invalid CVV$")
	public void enter_the_invalid_CVV() throws Throwable {
	   
		PageFactPack.PageFactory.SendValue(ElementLocators.CVV, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Make_payment);
	}

	@Then("^Accept the Alert for CVV$")
	public void accept_the_Alert_for_CVV() throws Throwable {
	    
		PageFactPack.PageFactory.Alert("Please enter valid CVV");
	}

	@Then("^Enter the valid CVV$")
	public void enter_the_valid_CVV() throws Throwable {
	   
		PageFactPack.PageFactory.select(ElementLocators.CVV,"799");
	}

	@When("^Enter the invalid Expiration Month$")
	public void enter_the_invalid_Expiration_Month() throws Throwable {
	   
		PageFactPack.PageFactory.SendValue(ElementLocators.Expiration_Month, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Make_payment);
	}

	@Then("^Accept the Alert for Expiration Month$")
	public void accept_the_Alert_for_Expiration_Month() throws Throwable {
	   
		PageFactPack.PageFactory.Alert("Please enter valid Expiry month");
	}

	@Then("^Enter the valid Expiration Month$")
	public void enter_the_valid_Expiration_Month() throws Throwable {
	
		PageFactPack.PageFactory.select(ElementLocators.Expiration_Month,"April");
	}

	@When("^Enter the invalid Expiration Year$")
	public void enter_the_invalid_Expiration_Year() throws Throwable {
	    
		PageFactPack.PageFactory.SendValue(ElementLocators.Expiration_Year, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Make_payment);
	}

	@Then("^Accept the Alert for Expiration Year$")
	public void accept_the_Alert_for_Expiration_Year() throws Throwable {
	    
		PageFactPack.PageFactory.Alert("Please enter valid Expiry year");
	}

	@Then("^Enter the valid Expiration Year$")
	public void enter_the_valid_Expiration_Year() throws Throwable {
	   
		PageFactPack.PageFactory.select(ElementLocators.Expiration_Year,"2018");
	}
	
	@When("^clicks on Confirm Payment$")
	public void clicks_on_Confirm_Booking() throws Throwable {
		PageFactPack.PageFactory.clickmethod(ElementLocators.Make_payment);

	    
	}

	@Then("^User is successfully registered$")
	public void user_is_successfully_registered() throws Throwable {
	   
		PageFactPack.PageFactory.close();
	}
	

}
