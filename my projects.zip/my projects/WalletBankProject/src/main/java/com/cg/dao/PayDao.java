package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import com.cg.bean.PayBean;
import com.cg.util.CreateConnection;

public class PayDao {
	HashMap<Long,PayBean> map=new HashMap<Long,PayBean>();
	PayBean paybean=new PayBean();
	Connection con=null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	int row = 0;
	public void populateMap(HashMap<Long,PayBean>hm) {
		this.map=hm;
		
	}
	public void addUser(PayBean p) {
		try {
			con = CreateConnection.getConnection();
			String str = "insert into bankusers values(?,?,?,?,?)";
			ps = con.prepareStatement(str);
			ps.setLong(1, p.getAccno());
			ps.setLong(2, p.getPhnno());
			ps.setString(3, p.getName());
			ps.setDouble(4, p.getBalance());
			ps.setString(5, p.getAddress());
			ps.executeUpdate();
		}
		catch(SQLException e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null && ps!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your connection is not properly closed.");
				}
			}
		}
	}
 
	 public double display(long accno) {
		 try {
				con = CreateConnection.getConnection();
				String sql = "select balance from bankusers where accno=?";
				ps = con.prepareStatement(sql);
				ps.setLong(1, accno);
				rs = ps.executeQuery();
				rs.next();
				paybean.setBalance(rs.getDouble("balance"));
			} 
			catch (SQLException e) {
				System.out.println(e);
			}
			
			finally {
				if(con!=null) {
					try {
						ps.close();
						con.close();
					}
					catch(SQLException e) {
						System.out.println("Your Connection is not properly closed.");
					}
				}
			}
			return paybean.getBalance();
		}
 
 public boolean deposit(long accno,double balance) {
	 boolean res = false;
	 try {
			con = CreateConnection.getConnection();
			String sql = "update bankusers set balance=balance+? where accno=?";
			ps = con.prepareStatement(sql);
			ps.setDouble(1, balance);
			ps.setLong(2, accno);
			ps.executeUpdate();
			res = true;
			System.out.println("DONE");
		}
		catch(SQLException e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Connection is not properly closed.");
				}
			}
		}
	 return res;
 }
 
 public boolean Withdraw(long accno,double balance) {
	 boolean res = false;
	 try {
			con = CreateConnection.getConnection();
			String sql1 = "select balance from bankusers where accno=?";
			ps = con.prepareStatement(sql1);
			ps.setLong(1, accno);
			rs = ps.executeQuery();
			rs.next();
			Double bal = rs.getDouble("balance");
			if(bal<balance) {
				return res;
			}
			String sql2 = "update bankusers set balance=balance-? where accno=?";
			ps = con.prepareStatement(sql2);
			ps.setDouble(1, balance);
			ps.setLong(2, accno);
			ps.executeUpdate();
			res = true;
		}
		catch(SQLException e) {
			System.out.println(e);
		}
		finally {
			if(con!=null && ps!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Connection is not properly closed.");
				}
			}
		}
		return res;
 }
 
 public boolean transferFund(long sourceaccno,long destinationaccno,double transferamount) {
	 boolean res = false;
	 try {
			con = CreateConnection.getConnection();
			String sql1 = "select balance from bankusers where accNo=?";
			ps = con.prepareStatement(sql1);
			ps.setLong(1, sourceaccno);
			rs = ps.executeQuery();
			if(rs.next()==false)
				return res;
			Double bal = rs.getDouble("balance");
			if(bal<transferamount)
				return res;
			String sql2 = "update bankusers set balance=balance-? where accNo=?";
			ps = con.prepareStatement(sql2);
			ps.setDouble(1, transferamount);
			ps.setLong(2, sourceaccno);
			ps.executeUpdate();
			String sql3 = "update bankusers set balance=balance+? where accNo=?";
			ps= con.prepareStatement(sql3);
			ps.setDouble(1, transferamount);
			ps.setLong(2, destinationaccno);
			row = ps.executeUpdate();
			if(row<1)
				return res;
			else
				res = true;
		}
		catch(SQLException e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Connection is not properly closed.");
				}
			}
		}
		return res;
 }

}
