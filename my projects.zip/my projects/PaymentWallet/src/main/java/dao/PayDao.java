package dao;

import java.util.HashMap;

import bean.PayBean;

public class PayDao {
	HashMap<Long,PayBean> map=new HashMap<Long,PayBean>();
	PayBean paybean=new PayBean();
	
	
	public void populateMap(HashMap<Long,PayBean>hm) {
		this.map=hm;
		
	}
	public void addUser(PayBean p)
	{
		
		map.put(p.getAccno(),p);
	
	}
	
 
 public double display(long accno)
 {
 	double result=0; 	
 	if(this.map().containsKey(accno))
 	{
 		 result=(this.map().get(accno).getBalance());
 		}
 	else
 	{
 	result=-1;
 		}
 	
 return result;
 	
 }
 
 public boolean deposit(long accno,double balance)
 {
 	double bal;
 	boolean res=false;

 	if(this.map().containsKey(accno))
 	{
 		bal=balance+(this.map().get(accno).getBalance());
 		this.map().get(accno).setBalance(bal);
 		 res=true;
 		}
 	else
 	{
 		res=false;
 	}
 	
 	return res;
 	
 		
 }
 
 public boolean Withdraw(long accno,double balance)
 {
 	double bal;
 	boolean re=false;
 	
 	if(this.map().containsKey(accno))
 	{
 		bal=(this.map().get(accno).getBalance())-balance;
 		this.map().get(accno).setBalance(bal);
 		 re=true;
 		}
 	else
 	{
 		re=false;
 	}
 	
 	return re;
 	
 		
 }
 
 public boolean transferFund(long sourceaccno,long destinationaccno,double transferamount)
 {
 	boolean r=false;

 if(this.map().containsKey(sourceaccno)) {				
 	if(this.map().containsKey(destinationaccno)){
 		
 		if(this.map().get(sourceaccno).getBalance() > transferamount) {
 	}
 		double transfer = transferamount;
 		this.map().get(sourceaccno).setBalance(this.map().get(sourceaccno).getBalance() - transfer);		// DECREMENTING THE TRANSFER AMOUNT
 		this.map().get(destinationaccno).setBalance(this.map().get(destinationaccno).getBalance() + transfer);			// ADDING THE TRANSFER AMOUNT
 		System.out.println("Remaining balance in account number "+sourceaccno+" is: " +this.map().get(sourceaccno).getBalance());
 	    r=true;
 	}
 	else
 	{
 		r=false;
 	}
 	}

 return r;
 }
 
 public HashMap<Long,PayBean> map()
 {
	 return map;
	 
 }
 
}
