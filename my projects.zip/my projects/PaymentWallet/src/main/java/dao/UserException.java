package dao;

public class UserException extends Exception  {
	

}
