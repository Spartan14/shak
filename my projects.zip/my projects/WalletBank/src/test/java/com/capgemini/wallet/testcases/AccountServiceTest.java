package com.capgemini.wallet.testcases;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

import WalletBean.WalletBean;
import Walletdao.UserException;
import Walletdao.WalletDao;
public class AccountServiceTest {
	
	WalletDao serv=new WalletDao();
	WalletBean acOpen=new WalletBean();
	@Test
	public void checkAdd() throws UserException
	{
		acOpen.setName("sumit");
		acOpen.setMobNo(7417415646l);
		acOpen.setBalance(74000);
		acOpen.setAccNo(7417415679l);
		int actual=serv.addCustomer(acOpen);
		int expected=1;
		assertEquals(expected,actual);
	}
	@Test
	public void checkShowBal() throws UserException {
		boolean flag=false;
		long accNo=7417417361l;
		float res=serv.showBalance(accNo);
		if(res>0)
		{
			flag=true;
		}
		assertTrue(flag);
	}

	@Test
	public void testAddBalance() throws UserException
	{
		float expectedResult = 81000;
		float actualResult = serv.deposit(7417415692l, 1000f);
		assertEquals(expectedResult, actualResult);
	} 
	@Test
	public void testFundTransfer() throws UserException
	{
		Float expected=48000f;
		Float result=serv.transfer(1000f, 4154555568l, 7445546454l);
		assertEquals(expected,result);
	}
	@Test
	public void testdeposit() throws UserException
	{
		Float expected=8500f;
		Float result=serv.deposit(4154555568l,1000f);
		assertEquals(expected,result);
	}
}
