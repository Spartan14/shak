package Walletdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.bank.dbutil.DbUtil;

import WalletBean.WalletBean;

public class WalletDao {
	//WalletBean beanObj;
	

	WalletBean bean = new WalletBean();
	Double result= null;
	DbUtil DatabaseConnection;
	Connection con=null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	int row = 0;

	public int addCustomer(WalletBean bean) throws UserException {
		try {
			con = DbUtil.getConnection();
			String sql = "insert into wallet values(?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, bean.getName());
			ps.setLong(2, bean.getAccNo());
			ps.setLong(3, bean.getMobNo());
			ps.setFloat(4, bean.getBalance());
			row = ps.executeUpdate();
		}
		catch(Exception e) {
			throw new UserException ("Same phone no is already exist in account so account cannot created");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					throw new UserException ("Your Connection is not properly closed.");
				}
			}
		}
		return row;
	}
	
	public Float showBalance(Long ano) throws UserException{
		try {
			con = DbUtil.getConnection();
			String sql = "select bal from wallet where accNo=?";
			ps = con.prepareStatement(sql);
			ps.setLong(1, ano);
			rs = ps.executeQuery();
			if(rs.next()==false)
				throw new UserException("Account Number doesn't exist. Please check the account number");
			bean.setBalance(rs.getFloat("bal"));
		} 
		catch (SQLException e) {
			System.out.println(e);
		}
		
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Connection is not properly closed.");
				}
			}
		}
		return bean.getBalance();
	}
	
	public Float deposit(Long accountNumber,Float depositAmount) throws UserException{
		try {
			con = DbUtil.getConnection();
			String sql = "update wallet set bal=bal+? where accNo=?";
			ps = con.prepareStatement(sql);
			ps.setDouble(1, depositAmount);
			ps.setLong(2, accountNumber);
			row = ps.executeUpdate();
			if(row<1)
				throw new UserException("Account Number doesn't exist. Please check the account number");
			String sql2 = "select bal from wallet where accNo=?";
			ps = con.prepareStatement(sql2);	
			ps.setLong(1, accountNumber);
			rs = ps.executeQuery();
			rs.next();
			bean.setBalance(rs.getFloat("bal"));
		}
		catch(SQLException e) {
			throw new UserException("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					throw new UserException("Your Connection is not properly closed.");
				}
			}
		}
		return bean.getBalance();
	}
	
	public Float withdraw(Long accountNumber,Float withdrawAmount) throws UserException{
		try {
			con = DbUtil.getConnection();
			String sql1 = "select bal from wallet where accNo=?";
			ps = con.prepareStatement(sql1);
			ps.setLong(1, accountNumber);
			rs = ps.executeQuery();
			if(rs.next()==false)
				throw new UserException("Account Number doesn't exist. Please check the account number");
			Double bal = rs.getDouble("bal");
			if(bal<withdrawAmount)
				throw new UserException("Your account balance is not sufficient.");
			String sql2 = "update wallet set bal=bal-? where accNo=?";
			ps = con.prepareStatement(sql2);
			ps.setDouble(1, withdrawAmount);
			ps.setLong(2, accountNumber);
			ps.executeUpdate();
			ps = con.prepareStatement(sql1);
			ps.setLong(1, accountNumber);
			rs = ps.executeQuery();
			rs.next();
			bean.setBalance(rs.getFloat("bal"));
		}
		catch(SQLException e) {
			throw new UserException("Your Connection is not properly closed.");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					throw new UserException("Your Connection is not properly closed.");
				}
			}
		}
		return bean.getBalance();
	}
	
	public Float transfer(Float amount, Long sourceAccNo, Long receiverAccNo) throws UserException{
		try {
			con = DbUtil.getConnection();
			String sql1 = "select bal from wallet where accNo=?";
			ps = con.prepareStatement(sql1);
			ps.setLong(1, sourceAccNo);
			rs = ps.executeQuery();
			if(rs.next()==false)
				throw new UserException("Source Account Number doesn't exist. Please check the account number");
			Double bal = rs.getDouble("bal");
			if(bal<amount)
				throw new UserException("Your account balance is not sufficient.");
			String sql2 = "update wallet set bal=bal-? where accNo=?";
			ps = con.prepareStatement(sql2);
			ps.setDouble(1, amount);
			ps.setLong(2, sourceAccNo);
			ps.executeUpdate();
			String sql3 = "update wallet set bal=bal+? where accNo=?";
			ps= con.prepareStatement(sql3);
			ps.setDouble(1, amount);
			ps.setLong(2, receiverAccNo);
			row = ps.executeUpdate();
			if(row<1)
				throw new UserException("Receiver's Account Number doesn't exist. Please check the account number");
			String sql4 = "select bal from wallet where accNo=?";
			ps = con.prepareStatement(sql4);
			ps.setLong(1, receiverAccNo);
			rs = ps.executeQuery();
			rs.next();
			bean.setBalance(rs.getFloat("bal"));

		}
		catch(SQLException e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					throw new UserException("Your Connection is not properly closed.");
				}
			}
		}
		return bean.getBalance();
	}
}
