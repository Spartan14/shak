package WalletUI;
import java.util.Scanner;
import java.util.regex.Pattern;
public class Validation{
	Scanner sc = new Scanner(System.in);
	//validation method

	//  Check the desired amount is available or not
	public float amountCheck(float amount) {
		while(true) {
			if(amount<0) {
				try
				{
				System.out.println("Amount should be greater than 0.");
				System.out.println("Enter again: ");
				amount = sc.nextInt();
			}
				catch(Exception e)
				{
					System.out.println("Invalid Input Try again!!!");
				}
			}
			else {
				return amount;
			}
		}
	}
	
	// Check is correct or not
	public String nameCheck(String name) {
		while(true) {
			if(Pattern.matches("([A-Z])*([a-z])*", name)){
				return name;
			}
			else {
				System.out.println("Name should only have alphabets.");
				System.out.println("Enter again: ");
				name = sc.next();
			}
		}
	}
	
	//	check mobile number is valid or not
	public long mobCheck(long mob) { 
		while(true) {
			if(String.valueOf(mob).length()<10||String.valueOf(mob).length()>10) 
			{try
			{
				System.out.println("Enter valid mobile number.");
				mob = sc.nextLong();
			}
			catch(Exception e)
			{
				System.out.println("Invalid Input Try again!!!");
			}
			}
			else {
				return mob;
			}
		}
	}

}
