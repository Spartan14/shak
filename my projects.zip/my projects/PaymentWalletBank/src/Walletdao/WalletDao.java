package Walletdao;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import WalletBean.WalletBean;

public class WalletDao {
	//WalletBean beanObj;
	WalletBean bean = new WalletBean();
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("PaymentWalletBank");
	EntityManager em = emf.createEntityManager();
	EntityManager em1 = emf.createEntityManager();

	public void addCustomer(WalletBean bean) throws UserException {
		em.getTransaction().begin();
		em.persist(bean);
		em.getTransaction().commit();
	}
	
	public Float showBalance(Long ano) throws UserException{
		WalletBean bean = em.find(WalletBean.class, ano);
		if(bean!=null)
			return bean.getBalance();
		else
			throw new UserException("Account Number does not exist");
		
	}
	
	public Float deposit(Long accountNumber,Float depositAmount) throws UserException{
		WalletBean bean = em.find(WalletBean.class, accountNumber);
		if(bean!=null) {
			float bal  = bean.getBalance();
			bal = bal + depositAmount;
			em.getTransaction().begin();
			bean.setBalance(bal);
			em.getTransaction().commit();
			return bean.getBalance();
		}
		else
			throw new UserException("Account Number does not exist");
	}
	
	public Float withdraw(Long accountNumber,Float withdrawAmount) throws UserException{
		WalletBean bean = em.find(WalletBean.class, accountNumber);
		if(bean!=null) {
			float bal  = bean.getBalance();
			if(bal<=withdrawAmount)
				throw new UserException("Amount is not sufficient");
			bal = bal - withdrawAmount;
			em.getTransaction().begin();
			bean.setBalance(bal);
			em.getTransaction().commit();
			return bean.getBalance();
		}
		else
			throw new UserException("Account Number does not exist");	
	}
	
	public Float transfer(Float amount, Long sourceAccNo, Long receiverAccNo) throws UserException{
		WalletBean bean = em.find(WalletBean.class, sourceAccNo);
		if(bean!=null) {
			float bal  = bean.getBalance();
			if(bal<=amount)
				throw new UserException("Amount is not sufficient");
			bal = bal - amount;
			em.getTransaction().begin();
			bean.setBalance(bal);
		}
		else
			throw new UserException("Source Account Number does not exist");
		WalletBean bean1 = em1.find(WalletBean.class, receiverAccNo);
		if(bean1!=null) {
			float bal1 = bean1.getBalance();
			bal1 = bal1 + amount;
			em1.getTransaction().begin();
			bean1.setBalance(bal1);
		}
		else
			throw new UserException("Reciever Account Number does not exist");
		em.getTransaction().commit();
		em1.getTransaction().commit();
		return bean.getBalance();
	}
}
