package WalletService;

import WalletBean.WalletBean;
import Walletdao.UserException;
import Walletdao.WalletDao;

public class WalletService implements WalletServiceInt{
WalletDao daoObj = new WalletDao();
	
	public void bankAccountCreate(WalletBean bankBeanObjCreateAccountObj) throws UserException
	{
		daoObj.addCustomer(bankBeanObjCreateAccountObj);
	}
	
	public float showBalanceSer(long accNo)throws UserException 
	{
		float bal=daoObj.showBalance(accNo);
		return bal;
		
	}
	
	public float depositSer(long accNo,float bal)throws UserException{
		bal=daoObj.deposit(accNo,bal);
		return bal;
	}
	
	public float withdrawSer(float withdrawAmount,long accNo) throws UserException {
		float bal=daoObj.withdraw(accNo,withdrawAmount);	;
	return bal;
	}
	
	public Float transferSer(long sourceAccNo,long destAccNo, float transferAmount)  throws UserException {
		Float stmt=daoObj.transfer(transferAmount,sourceAccNo, destAccNo );
		return stmt;
	}
}

