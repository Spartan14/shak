package WalletService;

import WalletBean.WalletBean;
import Walletdao.UserException;

public interface WalletServiceInt {
	public Float transferSer(long sourceAccNo,long destAccNo,float transferAmount)throws UserException;
	public float withdrawSer(float withdrawAmount,long accNo)throws UserException;
	public float depositSer(long accNo,float bal)throws UserException;
	public float showBalanceSer(long accNo)throws UserException;
	public void bankAccountCreate(WalletBean bankBeanObjCreateAccountObj)throws UserException;

}
