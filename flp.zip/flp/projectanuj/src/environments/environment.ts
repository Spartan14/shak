/* SystemJS module definition */
export const environment = {
  production:false
};

// declare var module: NodeModule;
// interface NodeModule {
//   id: string;
// }
