import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ServiceService } from '../service.service';
import { DataService } from '../data.service';
@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
result:any
model;
merchantmail:string;
MerchantId:any;
ngOnInit() {
  
}
  constructor(private router:Router, private service: ServiceService,private data: DataService) { 
    this.data.currentMail.subscribe(message => this.merchantmail = message)
  this.service.getMerchantId(this.merchantmail).subscribe(data=>{this.MerchantId=data})
  }

  
  addproduct(add)
  {
    alert(add.price)
    this.service.addProduct( 
      {
        prodName:add.name,
        prodPrice:add.price,
        prodQuantity:add.quantity,
        prodDiscount:add.discount,
        prodCategory:add.category,
        prodDesc:add.desc,
        prodImage:add.image,
        merchantId:this.MerchantId
      }
    ).subscribe(data=>this.result=data)
    if (this.result =="added successfully")
    {
      alert("added successfully")
    }
    this.router.navigate(['/productpage'])
  }
}
