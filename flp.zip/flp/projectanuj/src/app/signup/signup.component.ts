import { Component, OnInit } from '@angular/core';
import { NgIf } from '../../../node_modules/@angular/common';
import {Router} from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
result:any
merchantflag=false;

  constructor(private router: Router, private service: ServiceService) { }
  ngOnInit() {
  }
  setflag(add)
  {
    if(add.select=="merchant")
    {
      this.merchantflag=true;
      add.select="merchant"
    }
    else
    {
      this.merchantflag=false;
    }
  }
  signup(add)
  {
   
   if(add.select=="customer"){
    
   }
   else if(add.select=="merchant"){
    this.service.merchantAdd( 
      {
        merchantName:add.merchantName,
        phoneNo:add.phone,
        email:add.email,
        password:add.password,
        govtProofType:add.govt,
        govtProof:add.govt_id
      }
    ).subscribe(data=>this.result=data)
    alert("registered successfully")
    this.router.navigate(['/login'])

   }
   else{}
}
}

