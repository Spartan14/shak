import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Message } from '../app/message';
import { Observable } from '../../node_modules/rxjs';
import { map, filter, catchError, mergeMap } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ChatsocketService {
  url: string = "http://localhost:3456/"+ "api/socket";

  constructor(private http: HttpClient) { }

  post(data: Message) {
    return this.http.post<Message>(this.url, data);
  }
}
