import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  result: any;
  model;
  constructor(private router: Router, private service: ServiceService) { }
  a: any;

  ngOnInit() {
  }
  login(add) {
    if (add.email != null && add.password != null) {
      if (add.choice == "admin") {
        this.service.adminlogin(add).subscribe(data => {
          this.result = data
          if (this.result == "Login Successful") {
            alert(this.result)
            this.router.navigate(['/adminmanage'])
          }
          else {
            console.log(this.result)
            alert(this.result)
          }
        });
      }
      else if (add.choice == "merchant") {
        alert(add.email);
        this.service.merchantLogin(add).subscribe(data => {
          this.result = data
          if (this.result == "Login Successful") {
            alert(this.result)
            this.router.navigate(['/productpage'])
          }
          else {
            console.log(this.result)
            alert(this.result)
          }
        });
      }
    }

    else {
      alert("This is not admin page")
    }


    //console.log(add.email)
    //console.log(add.password)


  }
  
}
