import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from '../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  post(arg0: any): any {
    throw new Error("Method not implemented.");
  }
  url: string = environment.url+ "api/socket";
  private baseUrl='http://localhost:3456';
  constructor(private http:HttpClient) { }


  public adminlogin(admin):Observable<String>{
    return this.http.get(`${this.baseUrl}/login/${admin.email}/${admin.password}`,{responseType:"text"});
  }
  public viewmerchants():Observable<any>
  {
    return this.http.get(`${this.baseUrl}/login/`)
  }
  
  public deleteMerchant(merchantId):Observable<String>
  {
    return this.http.delete(`${this.baseUrl}/login`+`/`+`${merchantId}`,{responseType:"text"})
  }
  public vieworders():Observable<any>
  {
    return this.http.get(`${this.baseUrl}/login/orders`)
  }
  public deleteOrder(order_id):Observable<String>
  {
    return this.http.delete(`${this.baseUrl}/login`+`/`+`orders`+`/`+`${order_id}`,{responseType:"text"})
  }
  public viewcustomers():Observable<any>
  {
    return this.http.get(`${this.baseUrl}/login/showCustomers/`)
  }
  public removecustomers():Observable<any>
  {
    return this.http.delete(`${this.baseUrl}/login/deleteCustomers/{customerId}`)
  }
  public merchantLogin(merchant):Observable<String>{
    alert(merchant.email)
    return this.http.get(`${this.baseUrl}/loginMerchant/${merchant.email}/${merchant.password}`,{responseType:"text"});
  }
  public merchantAdd(merchant):Observable<String>{
    console.log(merchant)
    return this.http.post(`${this.baseUrl}/merchant/`,merchant,{responseType:"text"});
  }
}
