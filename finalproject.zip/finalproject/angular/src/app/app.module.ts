import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductpageComponent } from './productpage/productpage.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { TransactionComponent } from './transaction/transaction.component';
import { RefundComponent } from './refund/refund.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { GovtComponent } from './govt/govt.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './header/header.component';
import { OrdersComponent } from './orders/orders.component';
import { SearchBarPipePipe } from './search-bar-pipe.pipe';
import { ChatComponent } from './chat/chat.component';
import { ToastrModule } from '../../node_modules/ngx-toastr';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { ChangePasswordComponent } from './change-password/change-password.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductpageComponent,
    AddproductComponent,
    TransactionComponent,
    RefundComponent,
    SignupComponent,
    LoginComponent,
    GovtComponent,
    HeaderComponent,
    OrdersComponent,
    SearchBarPipePipe,
    ChatComponent,
    ChangePasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ToastrModule.forRoot({ timeOut: 3000 }),
    BrowserAnimationsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
