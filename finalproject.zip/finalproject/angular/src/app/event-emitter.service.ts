import { Injectable, EventEmitter } from '@angular/core';
import { Subscription } from '../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class EventEmitterService {

  invokeFirstComponentFunction = new EventEmitter();  
  invokeMail= new EventEmitter();  
  subsVar: Subscription;    
    
  constructor() { }    
    
  setText(text:string) {    
    this.invokeFirstComponentFunction.emit(text);    
  }  

  setMail(text:string){
    this.invokeMail.emit(text);
  }
}
