import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ServiceService } from '../service.service';
import { DataService } from '../data.service';
@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  result:any
  model;
  merchantmail:string;
  MerchantId:any;
  ngOnInit() {
  }
  constructor(private router:Router, private service: ServiceService,private data: DataService) { 
    this.data.currentMail.subscribe(message => this.merchantmail = message)
  this.service.getMerchantId(this.merchantmail).subscribe(data=>{this.MerchantId=data})
  }

  
  change(add)
  {

    this.service.change(this.merchantmail,add.newpassword).subscribe(data=>this.result=data)
    if (this.result =="added successfully")
    {
      alert("added successfully")
    }
    this.router.navigate(['/productpage'])
  }

}
