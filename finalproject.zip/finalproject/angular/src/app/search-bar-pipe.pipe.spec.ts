import { SearchBarPipePipe } from './search-bar-pipe.pipe';

describe('SearchBarPipePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchBarPipePipe();
    expect(pipe).toBeTruthy();
  });
});
