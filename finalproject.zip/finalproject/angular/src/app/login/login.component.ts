import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  result: any;
  model;
  merchantmail:string;
  constructor(private router: Router, private service: ServiceService,private data: DataService) { }
  a: any;
  email:any

  ngOnInit() {
    this.data.currentMail.subscribe(message => this.merchantmail = message)
  }
  forgotPass()
  {
    this.email=prompt("enter your email id");
    alert("Your password is reset and sent to your "+this.email);
  }
  login(add) {
    if (add.email != null && add.password != null) {
      if (add.choice == "admin") {
        this.service.adminlogin(add).subscribe(data => {
          this.result = data
          if (this.result == "Login Successful") {
            alert(this.result)
            this.router.navigate(['/adminmanage'])
          }
          else {
            console.log(this.result)
            alert(this.result)
          }
        });
      }
      else if (add.choice == "merchant") {
        this.service.merchantLogin(add).subscribe(data => {
          this.result = data
          if (this.result == "Login Successful") {
            alert(this.result)
            this.data.changeMail(add.email)
            this.router.navigate(['/productpage'])
          }
          else {
            console.log(this.result)
            alert(this.result)
          }
        });
      }
    }

    else {
      alert("This is not admin page")
    }


  

  }
  
}
