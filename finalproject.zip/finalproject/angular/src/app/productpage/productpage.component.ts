import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { DataService } from '../data.service';
import { EventEmitterService } from '../event-emitter.service';

@Component({
  selector: 'app-productpage',
  templateUrl: './productpage.component.html',
  styleUrls: ['./productpage.component.css']
})
export class ProductpageComponent implements OnInit {
product=[];
similar=[];
obj=[];
got=false;
all=true;
search:any
merchantmail:string;
  constructor(private service: ServiceService,private data: DataService,private eventEmitterService: EventEmitterService) {
    this.data.currentMail.subscribe(message => this.merchantmail = message)
    this.service.getMerchantProducts(this.merchantmail).subscribe(data=>{this.product=data})
   }

  ngOnInit() {
    if (this.eventEmitterService.subsVar==undefined) {    
      this.eventEmitterService.subsVar = this.eventEmitterService.    
      invokeFirstComponentFunction.subscribe((text:string) => {    
        this.setsearchText(text);    
      });    
    }  
    
  }
  

  setsearchText(text)
  {
    this.search={prod_Name: text}
    console.log(this.search)
  }
  sendIndex(index)
  {
    this.obj.splice(0,1)
    this.obj.push(this.product[index])
    let category=this.product[index].prod_Category;
    console.log(this.obj)
    this.got=true;
    this.all=false;
    this.similar.splice(0,10)
    this.product.forEach(element => {
      if(element.prod_Category==category)
      {
        this.similar.push(element)
      }
    });
  }
}
