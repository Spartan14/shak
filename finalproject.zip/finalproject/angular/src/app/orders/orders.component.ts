import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { DataService } from '../data.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  orders:any;
  merchantmail:string;
  constructor(private service: ServiceService,private data: DataService) {
    this.data.currentMail.subscribe(message => this.merchantmail = message)
    this.service.getMerchantOrders(this.merchantmail).subscribe(data=>{this.orders=data})
   }

  ngOnInit() {
  }

  accept(object)
  {
    let quantity=object.quantity;
    let product_id=object.prod_Id;
    let orderId=object.order_id;
    this.service.update(orderId);
    console.log(quantity,product_id,orderId)
  }

}
