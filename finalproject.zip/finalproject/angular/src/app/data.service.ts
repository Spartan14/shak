import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private messageSource = new BehaviorSubject('');
  currentMail = this.messageSource.asObservable();
  private searchtext=new BehaviorSubject('')
  currentSearch=this.searchtext.asObservable();

  constructor() { }

  changeMail(message: string) {
    this.messageSource.next(message)
  }

  changeSearch(search:string)
  {
    this.searchtext.next(search)
  }
}
