import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductpageComponent } from './productpage/productpage.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { TransactionComponent } from './transaction/transaction.component';
import { RefundComponent } from './refund/refund.component';
import { SignupComponent } from './signup/signup.component';
import { GovtComponent } from './govt/govt.component';
import { LoginComponent } from './login/login.component';
import { OrdersComponent } from './orders/orders.component';
import { ChatComponent } from './chat/chat.component';
import { ChangePasswordComponent } from './change-password/change-password.component';

const routes: Routes = [

  {
    path:'changepassword',
    component:ChangePasswordComponent
  },
  {
    path:'order',
    component:OrdersComponent
  },
  {
    path: 'addproduct',
    component: AddproductComponent
  },
  {
    path: '',
    component:LoginComponent
  },
  {
    path: 'transaction',
    component:TransactionComponent
  },
  {
    path: 'refund',
    component:RefundComponent
  },
  { path:  'signup',
   component:  SignupComponent
  },
  {
    path:  'login',
   component:LoginComponent
  },
  {
     path:  'govt', 
  component:  GovtComponent
},
{
  path:'productpage',
  component:ProductpageComponent
},
{
  path: 'chat',
  component: ChatComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
