import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { EventEmitterService } from '../event-emitter.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private data: DataService,private eventEmitterService: EventEmitterService) { }
searchText: any;
  ngOnInit() {
     
  }

  setsearch(text)
  { 
      this.eventEmitterService.setText(text);    
  }
}
