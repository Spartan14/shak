import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from '../../node_modules/rxjs';
import {Message} from '../app/message'

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  change(merchantmail,password): Observable<any> {
    return this.http.get('http://localhost:3456/change/'+merchantmail+'/'+password,{responseType:"text"})
  }
  post(arg0: any): any {
    throw new Error("Method not implemented.");
  }
  url: string = "http://localhost:3456/"+ "api/socket";
  private baseUrl='http://localhost:3456';
  constructor(private http:HttpClient) { }


  postchat(data: Message) {
    return this.http.post<Message>(this.url, data);
  }

  public getProductpage(category):Observable<any>{
    return this.http.get('http://localhost:3456/Productpage/'+category);
  }

  public update(oid){
    this.http.delete('http://localhost:3456/update/'+oid).subscribe(data=>console.log(data));
  }

  public getMerchantProducts(merchantmail):Observable<any>{
    return this.http.get('http://localhost:3456/getMerchantProducts/'+merchantmail)
  }

  public getMerchantOrders(merchantmail):Observable<any>{
    return this.http.get('http://localhost:3456/getMerchantOrders/'+merchantmail)
  }

  public Refund(transactionId):Observable<String>{
 
    return this.http.delete(`${this.baseUrl}/merchant`+`/`+`updateOrder`+`/`+`${transactionId}`,{responseType:"text"});
  
  }
  public RefundDetails():Observable<any>{
    return this.http.get(`${this.baseUrl}/merchant`)
  }

  public adminlogin(admin):Observable<String>{
    return this.http.get(`${this.baseUrl}/login/${admin.email}/${admin.password}`,{responseType:"text"});
  }
  public viewmerchants():Observable<any>
  {
    return this.http.get(`${this.baseUrl}/login/`)
  }
  
  public deleteMerchant(merchantId):Observable<String>
  {
    return this.http.delete(`${this.baseUrl}/login`+`/`+`${merchantId}`,{responseType:"text"})
  }
  public vieworders():Observable<any>
  {
    return this.http.get(`${this.baseUrl}/login/orders`)
  }
  public deleteOrder(order_id):Observable<String>
  {
    return this.http.delete(`${this.baseUrl}/login`+`/`+`orders`+`/`+`${order_id}`,{responseType:"text"})
  }
  public viewcustomers():Observable<any>
  {
    return this.http.get(`${this.baseUrl}/login/showCustomers/`)
  }
  public removecustomers():Observable<any>
  {
    return this.http.delete(`${this.baseUrl}/login/deleteCustomers/{customerId}`)
  }
  public merchantLogin(merchant):Observable<String>{
    return this.http.get(`${this.baseUrl}/loginMerchant/${merchant.email}/${merchant.password}`,{responseType:"text"});
  }
  public merchantAdd(merchant):Observable<String>{
    console.log(merchant)
    return this.http.post(`${this.baseUrl}/merchant/`,merchant,{responseType:"text"});
  }
  public addProduct(product):Observable<String>{
    return this.http.post(`${this.baseUrl}/addproduct/`,product,{responseType:"text"});
  }
  public getMerchantId(merchantMail):Observable<any> {

    return this.http.get(`${this.baseUrl}/merchant/`+merchantMail)
  }
}
