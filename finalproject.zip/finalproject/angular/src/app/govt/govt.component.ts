import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-govt',
  templateUrl: './govt.component.html',
  styleUrls: ['./govt.component.css']
})
export class GovtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
update(add)
{
  
}
}
