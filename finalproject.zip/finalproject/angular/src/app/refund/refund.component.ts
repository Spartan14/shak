import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-refund',
  templateUrl: './refund.component.html',
  styleUrls: ['./refund.component.css']
})
export class RefundComponent implements OnInit {
  Transaction:any
  result:any

  constructor(private service: ServiceService) 
  { 
    this.service.RefundDetails().subscribe(data => {
      this.Transaction = data
     
    });
  }

  ngOnInit() {
  }

  update(i)
  {
    
    this.service.Refund(this.Transaction[i].transaction_Id).subscribe(data => {
      this.result = data
      alert(data);
      if (this.result == "refund will be initiated") {
        alert("refund will be initiated");
      }
    });
    this.service.RefundDetails().subscribe(data => {
      this.Transaction = data
     
    });
}

delete(i)
{

  this.service.Refund(this.Transaction[i].transaction_Id).subscribe(data => {
    this.result = data
    alert(data);
    if (this.result == "refund will be initiated") {
      alert("refund is declined");
    }
  });
}
}