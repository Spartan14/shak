package com.capstore.model;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Transaction {
	@Id
	long transactionId;
	long productId;
	double amount;
	String statusOfPayment;
	String modeOfPayment;
    long customerId;
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getStatusOfPayment() {
		return statusOfPayment;
	}
	public void setStatusOfPayment(String statusOfPayment) {
		this.statusOfPayment = statusOfPayment;
	}
	public String getModeOfPayment() {
		return modeOfPayment;
	}
	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}
    public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	
	

}
