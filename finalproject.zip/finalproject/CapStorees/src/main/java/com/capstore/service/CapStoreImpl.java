package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.model.AdminLogin;
import com.capstore.model.Customer_Orders;
import com.capstore.model.Customers;
import com.capstore.model.Merchant;
import com.capstore.model.Products;
import com.capstore.model.Refund;
import com.capstore.model.Transaction;
import com.capstore.repository.CapstoreRepository;
import com.capstore.repository.CustomerOrderRepository;
import com.capstore.repository.CustomerRepository;
import com.capstore.repository.MerchantRepository;
import com.capstore.repository.ProductRepository;
import com.capstore.repository.RefundRepository;
import com.capstore.repository.TransactionRepository;

@Service
public class CapStoreImpl implements ICapStore {
	@Autowired
	CapstoreRepository repository;
	@Autowired
	MerchantRepository merchantRepository;
	@Autowired
	CustomerOrderRepository orderRepository;
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	ProductRepository product;
	@Autowired
	RefundRepository refundRepository;
	@Autowired
	TransactionRepository transactionRepository;

	public String login(String email, String password) {

		Optional<AdminLogin> opt = repository.findById(email);
		if (opt.isPresent()) {
			AdminLogin login = opt.get();
			if (login.getPassword().equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		} else {
			return "Login Failed";
		}

	}
	
	public String loginMerchant(String email, String password) {
		System.out.println(email);
		Optional<Merchant> opt = merchantRepository.findByEmail(email);
		if (opt.isPresent()) {
			Merchant login = opt.get();
			if (login.getPassword().equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		} else {
			return "Login Failed";
		}

	}

	public List<Merchant> getMerchant() {

		List<Merchant> list = new ArrayList<Merchant>();
		list = merchantRepository.findAll();
		return list;
	}

	@Override
	public String deleteMerchant(long merchantId) {
		Optional<Merchant> opt = merchantRepository.findById(merchantId);
		if (opt.isPresent()) {
			Merchant merchants = opt.get();
			merchantRepository.delete(merchants);
			return "Merchant details deleted successfully";

		} else {
			return "Merchant Not Found";
		}

	}

	@Override
	public List<Customer_Orders> showOrders() {

		List<Customer_Orders> list = new ArrayList<Customer_Orders>();
		list = orderRepository.findAll();
		return list;
	}

	@Override
	public String deleteOrder(int order_id) {
		Optional<Customer_Orders> opt = orderRepository.findById(order_id);
		if (opt.isPresent()) {
			Customer_Orders order = opt.get();
			orderRepository.delete(order);
			return "Order deleted successfully";

		} else {
			return "Order Not Found";
		}

	}

	public List<Customers> getCustomers() {
		List<Customers> list = new ArrayList<Customers>();
		list = customerRepository.findAll();
		return list;
	}

	public String deleteCustomers(long customerId) {
		Optional<Customers> opt = customerRepository.findById(customerId);
		if (opt.isPresent()) {
			Customers customer = opt.get();
			customerRepository.delete(customer);
		} else {
			return "Customer with " + customerId + " does not exist";
		}
		return "Customer details deleted successfully";
	}

	public String addMerchant(Merchant m) {
		merchantRepository.save(m);
		return "redirecting to your final step of signing up";
	}

	public List<Products> getMerchantProducts(String mail) {
		// TODO Auto-generated method stub
		Optional<Merchant> m=merchantRepository.findByEmail(mail);
		Merchant merchant=m.get();
		return product.findbyMerchant(merchant.getMerchantId());
	}
	
	public String refund(long transactionId) 
	{
		Optional<Refund> opt = refundRepository.findById(transactionId);
		System.out.println(opt.get().getTransaction_Id());
		Optional<Transaction> opt1= transactionRepository.findById(transactionId);
		if (opt.isPresent()|| opt1.isPresent())
		{
		refundRepository.deleteById(transactionId);
		Transaction trns=opt1.get();
		trns.setStatusOfPayment("refund");
		transactionRepository.save(trns);
		return "refund will be initiated";
		}
		else 
		{
			
			return "refund cannot be processed";
			
		}
		
		}
	public List<Refund> getAllOrder() {
		return refundRepository.findAll();
	}

	public List<Customer_Orders> getMerchantOrders(String mail) {
		// TODO Auto-generated method stub
		Optional<Merchant> m=merchantRepository.findByEmail(mail);
		Merchant merchant=m.get();
		return orderRepository.findbyMerchant(merchant.getMerchantId());
	}

	public void updateOrders(int oid) {
		// TODO Auto-generated method stub
		Optional<Customer_Orders> order=orderRepository.findById(oid);
		long pid=order.get().getProd_Id();
		int quantity=order.get().getQuantity();
		Optional<Products> p=product.findById(pid);
		Products prod=p.get();
		prod.setProd_Quantity(prod.getProd_Quantity()-quantity);
		product.save(prod);
		
		orderRepository.delete(order.get());
	}
	
	public String addProduct(Products p) {
		product.saveAndFlush(p);
		return "added successfully";
	}

	public Long getMerchantId(String email) {
		Long id=null;
		Optional<Merchant> opt=merchantRepository.findByEmail(email);
		if(opt.isPresent())
		{
			Merchant user=opt.get();
			id=user.getMerchantId();
		}
		return id;
	}

	public String change(String email, String password) {
		Optional<Merchant> opt=merchantRepository.findByEmail(email);
		if(opt.isPresent())
		{
			Merchant m=opt.get();
			m.setPassword(password);
			merchantRepository.save(m);
		}
		return "change successfully";
	}
}
