package com.capstore.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.model.Refund;
import com.capstore.service.CapStoreImpl;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class RefundController
{
	@Autowired
	CapStoreImpl service;
	
	@DeleteMapping(value = "/merchant/updateOrder/{transactionId}")
	public String updateOrder(@PathVariable("transactionId") Long transactionId)
	{
		String result=service.refund(transactionId);
		return result;
	}
	@GetMapping(value="/merchant")
	public List<Refund> allOrders()
	{
		return service.getAllOrder();
	}
	
} 
 