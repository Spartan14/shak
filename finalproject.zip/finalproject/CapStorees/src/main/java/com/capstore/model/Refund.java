package com.capstore.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="refund")
public class Refund 
{
	@Id
	long transactionId;
	long customerId;
	double refundedMoney;
	
	public Long getTransaction_Id() 
	{
		return transactionId;
	}
	public void setTransaction_Id(Long transactionId)
	{
		this.transactionId = transactionId;
	}
	public long getCustomer_Id() {
		return customerId;
	}
	public void setCustomer_Id(long customerId) 
	{
		this.customerId = customerId;
	}
	public double getRefundedMoney() {
		return refundedMoney;
	}
	public void setRefundedMoney(double refundedMoney) {
		this.refundedMoney = refundedMoney;
	}
	
}
